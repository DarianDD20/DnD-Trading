﻿namespace DnD_Trading
{
}

namespace DnD_Trading
{


    public partial class WstGrp22DataSet
    {
    }
}
namespace DnD_Trading {
    
    
    public partial class WstGrp22DataSet {
    }
}

namespace DnD_Trading.WstGrp22DataSetTableAdapters
{
    partial class UserTableAdapter
    {
    }

    public partial class SearchAddProductTableAdapter {
    }
}
